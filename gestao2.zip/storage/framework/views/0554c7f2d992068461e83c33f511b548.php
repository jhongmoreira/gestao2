<?php $__env->startSection('title','Clientes - Exata TI'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Vendas</h6>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Cliente</th>
                                <th>Servico</th>
                                <th>Valor</th>
                                <th>Pago</th>
                                <th>Vencimento</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Cliente</th>
                                <th>Servico</th>
                                <th>Valor</th>
                                <th>Pago</th>
                                <th>Vencimento</th>
                                <th>Ação</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $vendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <a href="<?php echo e(route('venda', $venda->id)); ?>"><?php echo e($venda->id); ?></a></td>
                                <td><?php echo e($venda->cliente->nome); ?></td>
                                <td><?php echo e($venda->servico->servico); ?></td>
                                <td><?php echo e('R$ ' . number_format($venda->valor_final, 2, ',', '.')); ?></td>
                                <td>
                                    <?php if($venda->pago == 0): ?>
                                    <p>Não</p>
                                    <?php else: ?>
                                    <p>Sim</p>
                                    <?php endif; ?>                                    
                                </td>
                                <td><?php echo e(date('d/m/Y', strtotime($venda->data_vencimento))); ?></td>
                                <td>
                                    <a href="<?php echo e(route('editar-venda', $venda->id)); ?>" class="btn btn-sm btn-warning mt-1"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('apagar-venda', $venda->id)); ?>" class="btn btn-sm btn-danger mt-1"><i class="fa fa-ban"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
                </div>
            </div>
</div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/venda/index.blade.php ENDPATH**/ ?>