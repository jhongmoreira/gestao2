<?php $__env->startSection('title','Apagar Venda - Exata TI'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12"><h3>Venda #<?php echo e($venda->id); ?></h3></div>
</div>

<hr>

<div class="row">
    <h1>Deseja realmente apagar a venda acima?</h1>
</div>

<form action="<?php echo e(route('delete-venda', $venda->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">    
        <div class="col-md-4 mt-2">
            <button type="submit" class="form-control btn btn-danger">Sim, desejo apagar</button>
        </div>
        <div class="col-md-4 mt-2">
            <a href="<?php echo e(route('home')); ?>" class="form-control btn btn-success">Cancelar</a>
        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/venda/delete.blade.php ENDPATH**/ ?>