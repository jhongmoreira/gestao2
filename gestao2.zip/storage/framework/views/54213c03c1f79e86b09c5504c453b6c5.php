<?php $__env->startSection('title','Venda - Exata TI'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12"><h3>Vender</h3></div>
</div>

<form action="<?php echo e(route('salvar-venda')); ?>" method="post">
    <?php echo csrf_field(); ?>

<div class="row">

    <div class="col-md-6">
        <div class="form-group">
            <label for="cliente">Cliente</label>
            <select name="cliente" id="cliente" class="form-control" required>
                <option value=""></option>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nome); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
            <label for="servico">Serviço</label>
            <select name="servico" id="servico" class="form-control" required>
                <option value=""></option>
                <?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($servico->id); ?>"><?php echo e($servico->servico); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-md-2">
        <div class="form-group">
          <label for="valor_final">Valor</label>
          <input type="number" step="0.01" name="valor_final" id="valor_final" class="form-control">
        </div>
    </div>

</div>    

<div class="row">

    <div class="col-md-4">
        <div class="form-group">
          <label for="data_venda">Data Venda</label>
          <input type="date" name="data_venda" id="data_venda" class="form-control">
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="data_vencimento">Data Vencimento</label>
          <input type="date" name="data_vencimento" id="data_vencimento" class="form-control">
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="pago">Pago</label>
            <select id="pago" name="pago" class="form-control" required>
                <option value=""></option>
                <option value="1">Sim</option>
                <option value="0">Não</option>
            </select>
        </div>
    </div>

</div>   

<div class="row">
    <div class="col-md-3">
        <button class="form-control btn btn-primary" type="submit">Cadastrar</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/venda/create.blade.php ENDPATH**/ ?>