<?php $__env->startSection('title','Detalhe do Cliente - Exata TI'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12"><h3><?php echo e($cliente->nome); ?></h3></div>
</div>

<hr>

<div class="row">
    <h1>Deseja realmente apagar o cliente acima?</h1>
</div>

<form action="<?php echo e(route('delete-cliente', $cliente->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">    
        <div class="col-md-4 mt-2">
            <button type="submit" class="form-control btn btn-danger">Sim, desejo apagar</button>
        </div>
        <div class="col-md-4 mt-2">
            <a href="<?php echo e(route('home')); ?>" class="form-control btn btn-success">Cancelar</a>
        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/cliente/delete.blade.php ENDPATH**/ ?>