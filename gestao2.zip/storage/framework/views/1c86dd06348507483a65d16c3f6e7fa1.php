<?php $__env->startSection('title','Editar Venda - Exata TI'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12"><h3>Editar Venda #<?php echo e($venda->id); ?></h3></div>
</div>

<form action="<?php echo e(route('update-venda', $venda->id)); ?>" method="post">
    <?php echo csrf_field(); ?>

<div class="row">

    <div class="col-md-6">
        <div class="form-group">
            <label for="cliente">Cliente</label>
            <select name="cliente" id="cliente" class="form-control" required>
                <option value=""></option>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($venda->cliente_id == $cliente->id): ?>
                        <option value="<?php echo e($cliente->id); ?>" selected><?php echo e($cliente->nome); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nome); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
            <label for="servico">Serviço</label>
            <select name="servico" id="servico" class="form-control" required>
                <option value=""></option>
                <?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($venda->servico_id == $servico->id): ?>                        
                        <option value="<?php echo e($servico->id); ?>" selected><?php echo e($servico->servico); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($servico->id); ?>"><?php echo e($servico->servico); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-md-2">
        <div class="form-group">
          <label for="valor_final">Valor</label>
          <input type="number" step="0.01" name="valor_final" id="valor_final" class="form-control" value="<?php echo e($venda->valor_final); ?>">
        </div>
    </div>

</div>    

<div class="row">

    <div class="col-md-4">
        <div class="form-group">
          <label for="data_venda">Data Venda</label>
          <input type="date" name="data_venda" id="data_venda" class="form-control" value="<?php echo e($venda->data_venda); ?>">
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="data_vencimento">Data Vencimento</label>
          <input type="date" name="data_vencimento" id="data_vencimento" class="form-control" value="<?php echo e($venda->data_vencimento); ?>">
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="pago">Pago</label>
            <select id="pago" name="pago" class="form-control" required>
                <option value=""></option>
                <option value="1" <?php echo e($venda->pago == 1 ? 'selected' : ''); ?>>Sim</option>
                <option value="0" <?php echo e($venda->pago == 0 ? 'selected' : ''); ?>>Não</option>
            </select>
        </div>
    </div>

</div>   

<div class="row">
    <div class="col-md-3">
        <button class="form-control btn btn-warning" type="submit">Atualizar</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/venda/edit.blade.php ENDPATH**/ ?>