<?php $__env->startSection('title','Novo Cliente - Exata TI'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12"><h3>Editando <?php echo e($servico->servico); ?></h3></div>
</div>

<form action="<?php echo e(route('update-servico', $servico->id)); ?>" method="post">
    <?php echo csrf_field(); ?>

<div class="row">

<div class="col-md-6">
        <div class="form-group">
          <label for="servico">Descrição do Servico</label>
          <input type="text" name="servico" id="servico" class="form-control" value="<?php echo e($servico->servico); ?>">
        </div>
    </div>

    <div class="col-md-2">
        <div class="form-group">
          <label for="valor">Valor</label>
          <input type="number" step="0.01" name="valor" id="valor" class="form-control" value="<?php echo e($servico->valor); ?>">
        </div>
    </div>  
    
</div>

<div class="row">
    <div class="col-md-3">
        <button class="form-control btn btn-warning" type="submit">Atualizar</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/servico/edit.blade.php ENDPATH**/ ?>