<?php $__env->startSection('title','Clientes - Exata TI'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Todos os Clientes</h6>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Whatsapp</th>
                                <th>E-mail</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Whatsapp</th>
                                <th>E-mail</th>
                                <th>Ação</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cliente->nome); ?></td>
                                <td><?php echo e($cliente->cpf); ?></td>
                                <td><?php echo e($cliente->whatsapp); ?></td>
                                <td><?php echo e($cliente->email); ?></td>
                                <td>
                                    <a href="<?php echo e(route('cliente', $cliente->id)); ?>" class="btn btn-sm btn-primary mt-1"><i class="fa fa-eye"></i></a>
                                    <a href="<?php echo e($cliente->pasta); ?>" target="_blank" class="btn btn-sm btn-secondary mt-1"><i class="fa fa-folder"></i></a>
                                    <a href="<?php echo e(route('editar-cliente', $cliente->id)); ?>" class="btn btn-sm btn-warning mt-1"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('apagar-cliente', $cliente->id)); ?>" class="btn btn-sm btn-danger mt-1"><i class="fa fa-ban"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
                </div>
            </div>
</div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/cliente/index.blade.php ENDPATH**/ ?>